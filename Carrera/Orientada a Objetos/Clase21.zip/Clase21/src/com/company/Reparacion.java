package com.company;

public class Reparacion{

    private String nombreArticulo;
    private Double costo;
    private String direccionEntrega;
    private StateReparacion estadoActual;

    public Reparacion(String nombreArticulo, Double costo, String direccionEntrega) {
        this.nombreArticulo = nombreArticulo;
        this.costo = costo;
        this.direccionEntrega = direccionEntrega;
        this.estadoActual = new StatePresupuesto();
    }

    public void pasoSiguiente(){
        estadoActual = estadoActual.pasarSiguientePaso();
        System.out.println(estadoActual);
    }

    public void otraDireccion(){
        try {
            estadoActual = estadoActual.cambiarDireccion();
        } catch (StateReparacionException e) {
            e.printStackTrace();
        }
        System.out.println(estadoActual);
    }


    public void darUnValor(){
        try {
            estadoActual = estadoActual.darValorDelPresupuesto();
        } catch (StateReparacionException e) {
            e.printStackTrace();
        }
        System.out.println(estadoActual);
    }


    public void ponerMasRepuestos(){
        try {
            estadoActual = estadoActual.agregarRepuestos();
        } catch (StateReparacionException e) {
            e.printStackTrace();
        }
        System.out.println(estadoActual);
    }



}
