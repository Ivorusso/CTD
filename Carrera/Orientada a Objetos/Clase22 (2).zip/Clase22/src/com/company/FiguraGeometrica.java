package com.company;

public interface FiguraGeometrica {

    public Double calcularSuperficie();
}
