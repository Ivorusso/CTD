package com.company;

public class ProductoFactoryException extends Exception {
    public ProductoFactoryException(String message) {
        super(message);
    }
}
