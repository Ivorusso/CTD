package com.company;

public abstract class Producto {
    private Double peso;

    public abstract  Double calcularEspacio();
}
