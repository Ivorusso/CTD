package com.company;

public class StateReparacionException extends Exception{

    public StateReparacionException(String message) {
        super(message);
    }
}
