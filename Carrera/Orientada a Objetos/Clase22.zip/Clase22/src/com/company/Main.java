package com.company;

public class Main {

    public static void main(String[] args) {
	Rectangulo rectangulo = new Rectangulo(5.0, 4.0);
    Circulo circulo = new Circulo(1.0);

    FiguraGeometricaComposite figuraGeometricaComposite = new FiguraGeometricaComposite();
    figuraGeometricaComposite.agregarFigura(rectangulo);
    figuraGeometricaComposite.agregarFigura(circulo);
    figuraGeometricaComposite.agregarFigura(circulo);
    figuraGeometricaComposite.agregarFigura(circulo);
    figuraGeometricaComposite.calcularSuperficie();

    }
}
