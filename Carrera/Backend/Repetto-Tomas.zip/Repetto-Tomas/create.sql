CREATE TABLE if not exists odontologo (id Long not null primary key,
matricula  varchar(255),
nombre varchar(255),
apellido varchar(255));
