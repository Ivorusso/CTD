package com.example.clase23Integradora;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Clase23IntegradoraApplicationTests {

	@Test
	void contextLoads() {

	}

}
