package com.example.clase23Integradora;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase23IntegradoraApplication {

	public static void main(String[] args) {
		SpringApplication.run(Clase23IntegradoraApplication.class, args);
	}

}
