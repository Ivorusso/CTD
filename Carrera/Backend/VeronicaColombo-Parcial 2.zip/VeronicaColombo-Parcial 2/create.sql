create table if not exists odontologos (
    matricula Long auto_increment primary key,
    nombre varchar(255),
    apellido varchar (255)
    );

-- Pueden agregar acá sentencias Insert para precargar datos.