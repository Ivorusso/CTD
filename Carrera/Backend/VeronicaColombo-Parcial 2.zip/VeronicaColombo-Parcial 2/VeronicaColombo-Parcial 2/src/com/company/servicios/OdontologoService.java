package com.company.servicios;

import com.company.daos.IDao;
import com.company.entidadesModel.Odontologo;

import java.util.List;

public class OdontologoService {
    private IDao<Odontologo> odontologoIDao;


    //va a permitir setear este Dao, es decir este mecanismo de persistencia
    public void setOdontologoIDao(IDao<Odontologo> odontologoIDao) {
        this.odontologoIDao = odontologoIDao;
    }

    //vamos a hacer un metodo guardar
    public Odontologo guardarOdontologo(Odontologo o){
        //le vamos a delegar la responsabilidad al Dao
        //patron strategic, es decir, como voy a persistir nuestro objeto estudiante
        return odontologoIDao.guardar(o);
    }

    public void eliminarOdontologo(Long matricula){
        //le vamos a delegar la responsabilidad al Dao
        odontologoIDao.eliminar(matricula);
    }

    public Odontologo buscarOdontologo(Long matricula){
        //le vamos a delegar la responsabilidad al Dao
        return odontologoIDao.buscar(matricula);
    }

    public List<Odontologo> buscarTodos(){
        //le vamos a delegar la responsabilidad al Dao
        return odontologoIDao.buscarTodos();
    }
}

