package com.company.daos;

import com.company.entidadesModel.Odontologo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OdontologoDaoH2 implements IDao<Odontologo> {
    ///vamos a crear los atributos para la coneccion.
    private final static String DB_JDBC_DRIVER = "org.h2.Driver";
    private final static String DB_URL = "jdbc:h2:~/bd_odontologos;INIT=RUNSCRIPT FROM 'create.sql'";
    private final static String DB_USER = "sa";
    private final static String DB_PASSWORD = "";

    @Override
    public Odontologo guardar(Odontologo odontologo) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            //1. Levantar el driver y conectarnos
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER,DB_PASSWORD);

            //2. Crear una setencia -usamos preparStament
                    // porq vamos a pasar cada una de las partes dinamicas q tenga el query
            preparedStatement = connection.prepareStatement("INSERT INTO odontologos VALUES(?,?,?)");
                    // nos devuelve un objeto pS entonces creamos una variable Ps = null arriba
            preparedStatement.setLong(1, odontologo.getMatricula());
            preparedStatement.setString(2, odontologo.getNombre());
            preparedStatement.setString(3, odontologo.getApellido());

            //3. Ejecutar la sentencia
            preparedStatement.executeUpdate();
            preparedStatement.close();



        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return odontologo;
    }

    @Override
    public void eliminar(Long matricula) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            //1. Levantar el driver y conectarnos
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER,DB_PASSWORD);

            //2. Crear una setencia -usamos preparStament
            // porq vamos a pasar cada una de las partes dinamicas q tenga el query
            preparedStatement = connection.prepareStatement("DELETE FROM odontologos WHERE MATRICULA=?");
            // nos devuelve un objeto pS entonces creamos una variable Ps = null arriba
            preparedStatement.setLong(1, matricula);


            //3. Ejecutar la sentencia
            preparedStatement.executeUpdate();
            preparedStatement.close();



        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }

    @Override
    public Odontologo buscar(Long matricula) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        Odontologo odontologo = null;

        try {
            //1. Levantar el driver y conectarnos
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER,DB_PASSWORD);

            //2. Crear una setencia -usamos preparStament
            // porq vamos a pasar cada una de las partes dinamicas q tenga el query
            preparedStatement = connection.prepareStatement("SELECT * FROM odontologos WHERE MATRICULA=?");
            // nos devuelve un objeto pS entonces creamos una variable Ps = null arriba
            preparedStatement.setLong(1, matricula);


            //3. Ejecutar la sentencia ExecuteQuery, porq no es un update. Nos va a devolver un obj del tipo Result
            ResultSet result = preparedStatement.executeQuery();

            //4. Evaluar los resultados
            while (result.next()){
                Long idMatricula = result.getLong("matricula");
                String nombre = result.getString("nombre");
                String apellido = result.getString("apellido");
                ///por cada id nos devuelve un estudiante entonces creamos arriba Estudiante estudiante = null;
                odontologo = new Odontologo();
                odontologo.setMatricula(idMatricula);
                odontologo.setApellido(apellido);
                odontologo.setNombre(nombre);
            }

            preparedStatement.close();

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return odontologo;
    }

    @Override
    public List<Odontologo> buscarTodos() {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        List<Odontologo> odontologos = new ArrayList();

        try {
            //1. Levantar el driver y conectarnos
            Class.forName(DB_JDBC_DRIVER);
            connection = DriverManager.getConnection(DB_URL, DB_USER,DB_PASSWORD);

            //2. Crear una setencia -usamos preparStament
            // porq vamos a pasar cada una de las partes dinamicas q tenga el query
            preparedStatement = connection.prepareStatement("SELECT * FROM odontologos");
            // nos devuelve un objeto pS entonces creamos una variable Ps = null arriba

            //3. Ejecutar la sentencia ExecuteQuery, porq no es un update. Nos va a devolver un obj del tipo Result
            ResultSet result = preparedStatement.executeQuery();

            //4. Evaluar los resultados
            while (result.next()){
                Long idMatricula = result.getLong("matricula");
                String nombre = result.getString("nombre");
                String apellido = result.getString("apellido");
                ///por cada id nos devuelve una lista de estudiantes entonces creamos arriba ArrayList estudiantes = new ArrayList();;
                Odontologo odontologo = new Odontologo();
                odontologo.setMatricula(idMatricula);
                odontologo.setApellido(apellido);
                odontologo.setNombre(nombre);

                odontologos.add(odontologo);
            }

            preparedStatement.close();

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return odontologos;
    }
}
