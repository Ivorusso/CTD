package com.company.test;

import com.company.daos.OdontologoDaoH2;
import com.company.entidadesModel.Odontologo;
import com.company.servicios.OdontologoService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class OdontologoServiceTest {
    @Test
    public void guardarOdontologo(){
        OdontologoService odontologoService = new OdontologoService();
        odontologoService.setOdontologoIDao(new OdontologoDaoH2());

        Odontologo odontologo = new Odontologo();
        odontologo.setMatricula(1L);
        odontologo.setNombre("vero");
        odontologo.setApellido("colombo");

        odontologoService.guardarOdontologo(odontologo);

        Assertions.assertTrue((odontologoService.buscarOdontologo(1L) != null));
    }


    @Test
    public void buscarOdontologo(){
        OdontologoService odontologoService = new OdontologoService();
        odontologoService.setOdontologoIDao(new OdontologoDaoH2());

        odontologoService.eliminarOdontologo(1L);

        Odontologo odontologo = new Odontologo();
        odontologo.setMatricula(1L);
        odontologo.setNombre("vero");
        odontologo.setApellido("colombo");

        odontologoService.guardarOdontologo(odontologo);
        odontologoService.buscarOdontologo(1L);

        Assertions.assertNotNull(odontologo);

    }

    @Test
    public void eliminarOdontologo(){
        OdontologoService odontologoService = new OdontologoService();
        odontologoService.setOdontologoIDao(new OdontologoDaoH2());

        odontologoService.eliminarOdontologo(1L);
        Odontologo odontologo = new Odontologo();
        odontologo.setMatricula(1L);
        odontologo.setNombre("vero");
        odontologo.setApellido("colombo");

        odontologoService.guardarOdontologo(odontologo);
        odontologoService.eliminarOdontologo(1L);

        Assertions.assertNull(odontologoService.buscarOdontologo(1L));
    }

    @Test
    public void listarTodos(){
        OdontologoService odontologoService = new OdontologoService();
        odontologoService.setOdontologoIDao(new OdontologoDaoH2());

        odontologoService.eliminarOdontologo(1L);
        odontologoService.eliminarOdontologo(2L);

        Odontologo odontologo = new Odontologo();
        odontologo.setMatricula(1L);
        odontologo.setNombre("vero");
        odontologo.setApellido("colombo");

        Odontologo odontologo1 = new Odontologo();
        odontologo1.setMatricula(2L);
        odontologo1.setNombre("veroo");
        odontologo1.setApellido("colomboo");

        odontologoService.guardarOdontologo(odontologo);
        odontologoService.guardarOdontologo(odontologo1);

        String res = "[Odontologo{matricula='1', nombre='vero', apellido='colombo'}, Odontologo{matricula='2', nombre='veroo', apellido='colomboo'}]";
        odontologoService.buscarTodos();

        Assertions.assertEquals(res, odontologoService.buscarTodos().toString());


    }
}
