package com.company;

import com.company.daos.OdontologoDaoH2;
import com.company.entidadesModel.Odontologo;
import com.company.servicios.OdontologoService;

public class Main {

    public static void main(String[] args) {

        Odontologo odontologo = new Odontologo();

        odontologo.setMatricula(10L);
        odontologo.setNombre("Florio");
        odontologo.setApellido("Florencio");

        OdontologoService odontologoService = new OdontologoService();
        //seteamos una estrategia de persistencia, es decir un DAO
        odontologoService.setOdontologoIDao(new OdontologoDaoH2());
        odontologoService.guardarOdontologo(odontologo);
        odontologoService.buscarOdontologo(5l);
//        odontologoService.eliminarOdontologo(8l);


        System.out.println(odontologoService.buscarTodos());
    }
}
