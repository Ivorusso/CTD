package com.company.daos;

import java.util.List;

public interface IDao<T> {
    public T guardar(T t);
    public void eliminar(Long matricula);
    public T buscar(Long matricula);
    public List<T> buscarTodos();

}
