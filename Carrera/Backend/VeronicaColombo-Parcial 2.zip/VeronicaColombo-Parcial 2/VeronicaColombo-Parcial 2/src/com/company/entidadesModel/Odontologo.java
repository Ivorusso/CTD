package com.company.entidadesModel;

public class Odontologo {
    private Long matricula;
    private String nombre;
    private String apellido;

    //Porq ID: Todas las bases de datos, todos los mecanimos de persistencia a cada uno
    //de los registros delo elementos que persistimos se les suele poner un identificador único
    //que sea siempre incremental (primary key)


    public Long getMatricula() {
        return matricula;
    }

    public void setMatricula(Long matricula) {
        this.matricula = matricula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    @Override
    public String toString() {
        return "Odontologo{" +
                "matricula='" + matricula + '\'' +
                ", nombre='" + nombre + '\'' +
                ", apellido='" + apellido + '\'' +
                '}';
    }
}
