CREATE TABLE if not exists odontologos (matricula  varchar(255) not null primary key , nombre varchar(255), apellido varchar(255));
