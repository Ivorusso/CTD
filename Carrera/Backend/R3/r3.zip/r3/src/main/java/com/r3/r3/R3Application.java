package com.r3.r3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class R3Application {

	public static void main(String[] args) {
		SpringApplication.run(R3Application.class, args);
	}

}
