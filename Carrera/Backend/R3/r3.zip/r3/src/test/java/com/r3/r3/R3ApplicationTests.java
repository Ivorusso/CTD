package com.r3.r3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class R3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
