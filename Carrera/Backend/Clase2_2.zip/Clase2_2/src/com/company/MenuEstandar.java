package com.company;

public class MenuEstandar extends Menu {

    public MenuEstandar(Integer precioBase) {
        super(precioBase);
    }
}
